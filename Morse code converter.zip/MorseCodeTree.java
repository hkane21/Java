import java.util.ArrayList;

public class MorseCodeTree implements LinkedConverterTreeInterface<String> {

	private TreeNode<String> root; 
	
	public MorseCodeTree() {
		root = new TreeNode<String>("");
		buildTree();
	}
	@Override
	public TreeNode<String> getRoot() {
		return new TreeNode<>(root);
	}

	@Override
	public void setRoot(TreeNode<String> newNode) { 
		root = new TreeNode<>(newNode);
		
	}

	@Override
	public LinkedConverterTreeInterface<String> insert(String code, String result) {	 
		addNode(root, code, result);
        return this;
	}
	/**
	 * This is a recursive method that adds element to the correct position in the tree based on the code. 
	 * A '.' (dot) means traverse to the left. A "-" (dash) means traverse to the right. 
	 * The code ".-" would be stored as the right child of the left child of the root Algorithm 
	 for the recursive method:
	1. if there is only one character
	a. if the character is '.' (dot) store to the left of the current root
	b. if the character is "-" (dash) store to the right of the current root
	c. return
	2. if there is more than one character
	a. if the first character is "." (dot) new root becomes the left child
	b. if the first character is "-" (dash) new root becomes the right child
	c. new code becomes all the remaining characters in the code (beyond the first character)
	d. call addNode(new root, new code, letter)
	 */
	@Override
	public void addNode(TreeNode<String> root, String code, String letter) {
		 if (code.length()==1) {
			 if(code.equals("."))
				 root.leftChild = new TreeNode<>(letter);
			 else if (code.equals("-")) {
				 root.rightChild = new TreeNode<>(letter);
			 }
		 } else {
			 if (code.charAt(0)== '.') 
				 addNode(root.leftChild,code.substring(1),letter);
				 else 
					 addNode(root.rightChild, code.substring(1),letter);
		 		}
	}

	@Override
	public String fetch(String code) {	 
		return fetchNode(root, code);
	}
	/**
	 * * This is the recursive method that fetches the data of the TreeNode
	 * that corresponds with the code
	 * 
	 * @param root the root of the tree for this particular recursive instance of addNode
	 * @param code the code for this particular recursive instance of fetchNode
	 * @return the data corresponding to the code
	 */
	@Override
	public String fetchNode(TreeNode<String> root, String code) { 
		String data = "";
		if (code.length()==1) {
			 if(code.equals("."))
				 data = root.leftChild.getData();
			 else if (code.equals("-")) {
				 data = root.rightChild.getData();
				 }
		 } else {
			 if (code.charAt(0)== '.') 
				 data = fetchNode(root.leftChild,code.substring(1));
				 else 
				 data = fetchNode(root.rightChild, code.substring(1));
		 		}
		return data;
	}

	@Override
	public LinkedConverterTreeInterface<String> delete(String data) throws UnsupportedOperationException { 
		throw new UnsupportedOperationException();
	}

	@Override
	public LinkedConverterTreeInterface<String> update() throws UnsupportedOperationException { 
		 throw new UnsupportedOperationException();
	}

	@Override
	public void buildTree() {
		 root = new TreeNode<String>("");
		 
		insert(".", "e");
		insert("-", "t");
		insert("..", "i");
		insert(".-", "a");
		insert("-.", "n");
		insert("--", "m");
		insert("...", "s");
		insert("..-", "u");
		insert(".-.", "r");
		insert(".--", "w");
		insert("-..", "d");
		insert("-.-", "k");
		insert("--.", "g");
		insert("---", "o");
		insert("....", "h");
		insert("...-", "v");
		insert("..-.", "f");
		insert(".-..", "l");
		insert(".--.", "p");
		insert(".---", "j");
		insert("-...", "b");
		insert("-..-", "x");
		insert("-.-.", "c");
		insert("-.--", "y");
		insert("--..", "z");
		insert("--.-", "q");
	}

	@Override
	public ArrayList<String> toArrayList() {
		ArrayList<String> TreeList = new ArrayList<>();
        LNRoutputTraversal(root, TreeList);
        return TreeList;
	}

	@Override
	public void LNRoutputTraversal(TreeNode<String> root, ArrayList<String> list) {
		if (root == null) {
			return;
		}
		else {
			LNRoutputTraversal(root.leftChild,list);
			list.add(root.getData());
			LNRoutputTraversal(root.rightChild,list);
		}
	}

	

}
