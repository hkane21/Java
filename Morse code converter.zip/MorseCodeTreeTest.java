import static org.junit.Assert.*;


import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class MorseCodeTreeTest {
	
	MorseCodeTree tree;

	@Before
	public void setUp() throws Exception {
		
		tree = new MorseCodeTree();
	}

	@After
	public void tearDown() throws Exception {
		
		tree = null;
	}


	@Test
	public void testInsert() {
		
		tree.insert(".....", "8");
		assertEquals("8", tree.fetch("....."));
	}

	@Test
	public void testGetRoot() {
		
		String result;
		result = tree.getRoot().getData();
		assertEquals("", result);
		
	}

	@Test
	public void testFetch() {

		assertEquals("h", tree.fetch("...."));
        assertEquals("f", tree.fetch("..-."));
        assertEquals("k", tree.fetch("-.-"));

	}

//	@Test
//	public void testUpdate() {
////		assertThrows();
//		assertTrue(true);
//	}
//	
//	@Test
//	public void testDelete() {
//		assertTrue(true)	;	
//	}
	
	
	@Test
	public void testToArrayList() {
		
		
		ArrayList<String> list = new  ArrayList<String>();
		
		list = tree.toArrayList();
		
		assertEquals("h", list.get(0));
		assertEquals("s", list.get(1));
		assertEquals("v", list.get(2));
		

	}
}