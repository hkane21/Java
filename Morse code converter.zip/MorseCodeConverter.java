import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MorseCodeConverter {

	private static MorseCodeTree tree = new MorseCodeTree();
	
	public MorseCodeConverter() {}
	
	public static String convertToEnglish(File codeFile) throws FileNotFoundException{
		Scanner input = new Scanner(codeFile);
        String text = "";
        while (input.hasNextLine()) {
            text += input.nextLine();
        }
        return convertToEnglish(text);
		
	}
	
	public static String convertToEnglish(String code){
		String str = "";
		String [] MorseWords = code.split(" ");
		for (String i : MorseWords ) {
			if (i.equals("/"))
				str += " ";
			else 
				str += tree.fetch(i);
		}
		return str;
	}
	
	public static String printTree(){
		String str = "";
		for (String i: tree.toArrayList())
			str += i+" ";
		
		return str;
		
	}
	
}
