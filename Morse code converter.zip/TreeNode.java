
public class TreeNode<T> {

	public TreeNode<T>rightChild;
	public TreeNode<T>leftChild;
	private T data;
	
	public TreeNode(T dataNode) {
	this.data=dataNode;
	}
	
	public TreeNode(TreeNode<T> node) {
		this.leftChild = node.leftChild;
		this.rightChild = node.rightChild;
		this.data = node.data;
	}
	
	public T getData() {
		return data;
	}
	
}
