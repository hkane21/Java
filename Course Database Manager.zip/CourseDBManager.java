import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface {

	CourseDBStructure CDS = new CourseDBStructure(100);
	CourseDBElement CDE = new CourseDBElement();
	
	@Override
	public void add(String id, int crn, int credits, String roomNum, String instructor) {
		// TODO Auto-generated method stub
		CourseDBElement CDE = new CourseDBElement(id, crn, credits, roomNum, instructor);
		CDS.add(CDE);
	}

	@Override
	public void readFile(File input) throws FileNotFoundException {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(input);
		while(scan.hasNextLine()) {
			
			add(scan.next(),scan.nextInt(),scan.nextInt(),
					scan.next(),scan.nextLine());
		}
		try{
			scan=new Scanner(input);
		}catch(FileNotFoundException e){
			System.exit(0);
		}

	}

	@Override
	public ArrayList<String> showAll() {
		// TODO Auto-generated method stub
		ArrayList<String> chain = new ArrayList<>();
//		 int temp=0;
//		 int ent = 0;
//		 CourseDBElement[] temp2  = new CourseDBElement[ent];	 
		 int slen = CDS.hashTable.length;
	        for(int i = 0; i < slen ; i++) {
	            if (CDS.hashTable[i] != null) {
	                LinkedList<CourseDBElement> list = CDS.hashTable[i];
	                for (CourseDBElement CDE : list) {
	                    chain.add(CDE.toString());
	                }
	            }
	        }
	        Collections.sort(chain);

	        return chain;
        
	}

	@Override
	public CourseDBElement get(int crn) {
		// TODO Auto-generated method stub
		try {
			return CDS.get(crn);
		}
		catch(Exception e)
		{
			return null;
		}
	}

}
