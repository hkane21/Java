import java.io.IOException;
import java.util.LinkedList;

public class CourseDBStructure implements CourseDBStructureInterface {

	protected LinkedList<CourseDBElement>[]hashTable;
	protected int tableSize;
	

	@SuppressWarnings("unchecked")
	public CourseDBStructure(String testing, int size) {
		tableSize = size;
		hashTable = (LinkedList<CourseDBElement>[]) new LinkedList[size];
	}
	
	@SuppressWarnings("unchecked")
	public CourseDBStructure(int size) {
		tableSize = size;
		hashTable = (LinkedList<CourseDBElement>[]) new LinkedList[size];
	}
	
	@Override
	public void add(CourseDBElement element) {
		// TODO Auto-generated method stub
		int hashCode = element.hashCode();
        int index = hashCode%tableSize;
        LinkedList<CourseDBElement> List = hashTable[index];
        
		if (List == null)
		{
			hashTable[index] = new LinkedList<CourseDBElement>();
		}
		CourseDBElement temp = new CourseDBElement(element.GetCourseID(), element.getCRN(), 
				element.getNumofCredits(), element.GetRoomNumber(), element.GetInstrName());
            hashTable[index].add(temp);
		
	}

	@Override
	public CourseDBElement get(int crn) throws IOException {
		// TODO Auto-generated method stub
		String stringCRN = Integer.toString(crn);
        int hashCODE = stringCRN.hashCode();
        int index = hashCODE%hashTable.length;
        int i = hashTable[index].indexOf(crn);
        if (hashTable[index].contains(crn)){
        	return hashTable[index].get(i);
        }
        else {
            throw new IOException();
        }
	}

	@Override
	public int getTableSize() {
		// TODO Auto-generated method stub
		return tableSize;
	}

}
