
public class CourseDBElement implements Comparable {

	private String CourseID;
	private int CRN;
	private int numofcredits;
	private String roomNumber;
	private String instrName;
	
	public CourseDBElement() {
		
	}
	
	/**
	 * 
	 * @param CourseID
	 * @param numofcredits
	 * @param CRN
	 * @param roomNumber
	 * @param instrName
	 */
	public CourseDBElement(String CID, int NOC, int CRN, String RNumber, String IName) {
		this.CourseID=CID;
		this.CRN=CRN;
		this.numofcredits=NOC;
		this.roomNumber=RNumber;
		this.instrName=IName;
	}
	
	@Override
	public int compareTo(CourseDBElement element) {
		
		return this.CRN-element.CRN;
	}
	public boolean equals(CourseDBElement element)
	{
		return this.compareTo(element) == 0;
	}
	public void setCRN(int crn) {
		CRN=crn;
	}
	public int getCRN() {
		return CRN;
	}
	public void SetCourseID(String id) {
		CourseID=id;
	}
	public String GetCourseID() {
		return CourseID;
	}
	public void setNumofCredits(int cred) {
		numofcredits=cred;
	}
	public int getNumofCredits() {
		return numofcredits;
	}
	public void SetRoomNumber(String RN) {
		roomNumber=RN;
	}
	public String GetRoomNumber() {
		return roomNumber;
	}
	public void SetInstrName(String insName) {
		instrName=insName;
	}
	public String GetInstrName() {
		return instrName;
	}

	public int hashCode() {
		String temp = Integer.toString(CRN);
		int hashcode = temp.hashCode();
		return hashcode;
	}
	
	public String toString() {
		String str = "\nCourse:" + CourseID + " CRN:" + CRN + " Credits:" 
				+ numofcredits + " Instructor:" + instrName + " Room:"+roomNumber;
		return str;
	}
	

}
