
public interface Comparable {

	public int compareTo(CourseDBElement element);
}
