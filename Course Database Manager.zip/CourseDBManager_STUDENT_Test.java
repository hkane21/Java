import static org.junit.Assert.*;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
/**
 * 
 * @author Hassan
 *
 */
public class CourseDBManager_STUDENT_Test {
	  private CourseDBManagerInterface CDM = new CourseDBManager();
	@Before
	public void setUp() throws Exception {
		CDM = new CourseDBManager();
	}
	@After
	public void tearDown() throws Exception {
		CDM = null;
	}
	@Test
	public void testAddToDB() {
		try {
			CDM.add("CHEM182",52534,4,"SCTrailer403","Walter White");
		}
		catch(Exception e) {
			fail("This should not have caused an Exception");
		}
	}
	
	/**
	 * Test for the showAll method
	 */
	@Test
	public void testShowAll() {
		CDM.add("CHEM182",52534,4,"SCTrailer403","Walter White");
		CDM.add("PHYS102",109010,12,"PS140","Bruce Banner");

		ArrayList<String> list = CDM.showAll();
		
		assertEquals(list.get(0),"\nCourse:CHEM182 CRN:52534 Credits:4 Instructor:Walter White Room:SCTrailer403");
		assertEquals(list.get(1),"\nCourse:PHYS102 CRN:109010 Credits:12 Instructor:Bruce Banner Room:PS140");
			}
	/**
	 * Test for the read method
	 */
	@Test
	public void testRead() {
		try {
			File inputFile = new File("Bang3.txt");
			PrintWriter inFile = new PrintWriter(inputFile);
			inFile.println("CHEM182 52534 4 SCTrailer403 Walter White");
			inFile.print("PHYS102 109010 12 PS140 Bruce Banner");
			
			inFile.close();
			CDM.readFile(inputFile);
		} catch (Exception e) {
			fail("Should not have thrown an exception");
		}
	}

}
