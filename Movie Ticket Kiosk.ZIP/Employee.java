

public class Employee extends Ticket{

	private int id;
	private int numVisits;
	/**
	 * No Arg employee constructor
	 */
	public Employee() {

	}
	/**
	 * @param id the employee id
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the number of visits to the movies
	 */
	public int getNumVisits() {
		return numVisits;
	}
	/**
	 * @param numVisits set the number of visits to the theater
	 */
	public void setTimes(int numVisits) {
		this.numVisits = numVisits;
	}
	/**
	 * 
	 * @param Name of movie	
	 * @param rating of movie
	 * @param Day of movie airing
	 * @param Time of movie start
	 * @param format of movie
	 * @param id employee identification
	 * @param numVisits employee number of visits
	 */
	public Employee(String Name, String rating, int Day, int Time, 
			String format,  int id, int numVisits) {
		super(Name,  Day, Time, format, rating, "Employee");
		this.id = id;
		this.numVisits = numVisits;
	}
	/**
	 * Return id
	 */
	public int getId() {
		return id;
	}
	/**
	 * Caluclation of an employee's ticket price
	 */
	public double calculateTicketPrice() {

		double price = 0;
		if(numVisits >= 2)
		{
			if(getMovieTime()>17) 
				price = 13.5;
			else price = 10.5;

			switch(getFormat())
		{
			case IMAX: price += 3.0;
			break;
			case THREE_D: price += 2.5;
			break;
			case NONE:
	    }

			price /= 2;
			price += price*0.096;
		}

		setPrice(price);

		return price;
		
	}
	/**
	 * Return to String method of Employee data
	 */
	public String toString() {
		String toString = "EMPLOYEE-" + id;
		toString += super.toString();
		return toString;	
	}	

}
