
import static org.junit.Assert.*;

	import org.junit.After;
	import org.junit.Before;
	import org.junit.Test;

	public class MoviePassTest {
		MoviePass m1,m2,m3,m4,m5,m6;
		

		@Before
		public void setUp() throws Exception {
			
			m1 = new MoviePass("Wolverine", "NR", 5,19,"NONE",22222,1,0,0);
			m2 = new MoviePass("Heat", "PG13", 2,12,"NONE",33333,0,0,0);
			m3 = new MoviePass("World War Z", "PG13", 3,20,"NONE",44444,4,1,0);
			m4 = new MoviePass("Justice League", "G", 1,13,"IMAX",55555,2,0,1);
			m5 = new MoviePass("Blade", "PG", 3,21,"NONE",66666,3,0,0);
			m6 = new MoviePass("Blade", "PG", 2,14,"3D",77777,3,0,0);
		}

		@After
		public void tearDown() throws Exception {
			m1=m2=m3=m4=m5=m6=null;
		}

		@Test
		public void test() {
			
			assertEquals(0.0,m1.calculateTicketPrice(),.01);
			assertEquals(9.99,m2.calculateTicketPrice(),.01);
			assertEquals(14.80,m3.calculateTicketPrice(),.01);
			assertEquals(14.80,m4.calculateTicketPrice(),.01);
			assertEquals(0.0,m5.calculateTicketPrice(),.01);
			assertEquals(14.25,m6.calculateTicketPrice(),.01);
			
		}

	}