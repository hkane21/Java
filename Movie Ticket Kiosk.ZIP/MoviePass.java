
public class MoviePass extends Ticket {

	private int id;
	private int times;
	private int num;
	private int numMovieS;
	
	
	/**
	 * 
	 * @param Name of movie
	 * @param rating of movie
	 * @param Day of movie
	 * @param Time of movie
	 * @param format of movie
	 * @param id of movie pass
	 * @param times of movie
	 * @param num times movie seen
	 * @param numMovie of movies
	 */
	public MoviePass(String Name, String rating, int Day, int Time,  
			String format, int id, int times, int num, int numMovie) {
		super(Name, Day, Time,  format, rating, "MoviePass");
		this.id = id;
		this.numMovieS = numMovie;
		this.times = times;
		this.num = num;
	}
	/**
	 * Calculates ticket price of movie pass 
	 */
	public double calculateTicketPrice() {
		price = 0;
		if (num < 1 && numMovieS < 1 && format == Format.NONE){
			if(times< 1)
				price = 9.99;
			else
			price = 0;
		}
		else {
			if(Time<18)
				price = 10.5;
			else if(getMovieTime()>17)
				price = 13.5;
			switch(format) {
			case IMAX:
				price += 3;
				break;
			case THREE_D:
				price += 2.5;
				break;
			case NONE:
				break;
			}
			price += price * 0.096;
		}
		
			setPrice(price);
			return price;
		
	}
	/**
	 * @param id sets the movie pass identification
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * returns movie pass identfication
	 */
	public int getId() {
		return id;
	}
	/**
	 * @return the time at which the Movie Pass movies are available for viewing
	 */
	public int getTimes() {
		return times;
	}
	/**
	 * @param times the times to set
	 */
	public void setTimes(int time) {
		this.times = time;
	}
	
	/**
	 * @return the current number of movies 
	 */
	public int getNumMovies() {
		return num;
	}
	/**
	 * @param num the number of movies is set
	 */
	public void setNum(int num) {
		this.num = num;
	}
	/**
	 * @return the number of times movie is seen
	 */
	public int getNumTimMovie() {
		return numMovieS;
	}

	/**
	 * To string method of movie pass id
	 */
	public String toString() {
		String toString = "MOVIEPASS-" + id;
		toString += super.toString();
		return toString;	
	}	

}
