
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AdultTest {
	Adult a1,a2,a3, a4, a5,a6;

	@Before
	public void setUp() throws Exception {
		a1 = new Adult("Toy Story", "G", 5,20,"NONE");
		a2 = new Adult("Cars", "G", 2,13,"NONE");
		a3 = new Adult("Lion King", "G",6,20,"IMAX");
		a4 = new Adult("Monsters Inc.", "G", 1,13,"IMAX");
		a5 = new Adult("Frozen", "PG", 3,21,"3D");
		a6 = new Adult("Dolittle", "PG", 2,14,"3D");
	}

	@After
	public void tearDown() throws Exception {
		a1=a2=a3=a4=a5=a6=null;
	}

	@Test
	public void test() {
		assertEquals(14.79,a1.calculateTicketPrice(),.01);
		assertEquals(11.508,a2.calculateTicketPrice(),.01);
		assertEquals(18.084,a3.calculateTicketPrice(),.01);
		assertEquals(14.796,a4.calculateTicketPrice(),.01);
		assertEquals(17.536,a5.calculateTicketPrice(),.01);
		assertEquals(14.248,a6.calculateTicketPrice(),.01);
	}

}