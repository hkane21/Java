import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Scanner;

public class MovieTicketManager implements MovieTicketManagerInterface{

	public enum Format {IMAX, THREE_D, NONE};

	private ArrayList<Ticket> ticketList=new ArrayList<>();
	private NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();

/**
 * No arg constructor that implements ticketList
 */
	public MovieTicketManager(){
	    ticketList = new ArrayList<Ticket>();
	}

/**
 * Returns the number of times this patron has visited the movies 
 */
	public int numVisits(int id){
		int numberOfVisits = 0;
		for(Ticket m : ticketList)
			if(m.getId()==id)
				numberOfVisits++;
		return numberOfVisits;
	}

/**
 * returns number of times the movie was watched
 */
	public int numThisMovie(int id, String movie){
		int numTimes = 0;
		for(Ticket m : ticketList)
			if(m.getId() == id)
				if(m.getMovieName().equals(movie))
					numTimes++;
		return numTimes;
	}
	
/**
 * number of times the movie was already seen
 */
	public int numMoviesToday(int id, int date){
		int numMovies = 0;
		for(Ticket NumberOfMoviesSeen : ticketList)
			if(NumberOfMoviesSeen.getId()==id)
				if(NumberOfMoviesSeen.getDay()==date)
					numMovies++;
		return numMovies;

	}

/**
 * Returns the price of the ticket based on which type of customer attends the theaters
 */
	public double addTicket(String movieN, String rating, int d, int t, String f, String type, int id){
		Ticket Customer;
		
		if(type.equals("Child")) {
			Customer = new Child(movieN,rating, d, t, f);
			ticketList.add(Customer);
			return Customer.calculateTicketPrice();
		}
		else if(type.equals("Adult")) {
			Customer = new Adult(movieN,rating, d, t, f);
			ticketList.add(Customer);
			return Customer.calculateTicketPrice();
		}
		else if(type.equals("Employee")) {

			int numV = numVisits(id);
			Customer = new Employee(movieN,rating, d, t, f,id,numV);
			ticketList.add(Customer);
			return Customer.calculateTicketPrice();
		}
		else if(type.equals("MoviePass")) {

				int numV = numVisits(id);
				int numTM = numThisMovie(id,movieN);
				int numM = numMoviesToday(id,d);
				Customer = new MoviePass(movieN,rating, d, t, f,id, numV,numTM, numM);
				ticketList.add(Customer);
				return Customer.calculateTicketPrice();
		}
		return -1;
	}

/**
 * Returns the sales for the entire month
 */

	public double totalSalesMonth(){
		double totalSales = 0;
		for(Ticket Sales : ticketList)
				{totalSales+=Sales.calculateTicketPrice();}
		return totalSales;
	}
/**
 * Returns the monthly sales report
 */
	public String monthlySalesReport(){
		String result = "";
		double totalSalesChild = 0,totalSalesAdult=0,totalSalesEmployee=0,totalSalesMoviePass=0;
		int numChild=0,numAdult=0,numMoviePass=0,numEmployee=0;
		for(Ticket SalesReport : ticketList)
		{
			switch (SalesReport.getType()){
			case "Adult":numAdult++; 
			totalSalesAdult+=SalesReport.calculateTicketPrice();
			break;
			case "Child":numChild++;
			totalSalesChild+=SalesReport.calculateTicketPrice();
			break;
			case "Employee":numEmployee++;
			totalSalesEmployee+=SalesReport.calculateTicketPrice();
			break;
			case "MoviePass":numMoviePass++;
			totalSalesMoviePass+=SalesReport.calculateTicketPrice();
			}
		}
			result += "	Monthly Sales Report\n\n";
			result += "			Sales		Number	\n";
			result +="ADULT		"+currencyFormat.format(totalSalesAdult)+"\t"+numAdult+"\n";
			result +="CHILD		"+currencyFormat.format(totalSalesChild)+"\t"+numChild+"\n";
			result +="EMPLOYEE		"+currencyFormat.format(totalSalesEmployee)+"\t"+numEmployee+"\n";
			result +="MOVIEPASS		"+currencyFormat.format(totalSalesMoviePass)+"\t"+numMoviePass+"\n";
			result +="\n"+"Total Monthly Sales: "+currencyFormat.format(totalSalesMonth());
	return result;
	}

/**
 *   Returns an arraylist of strings that represent 3D tickets sorted by day
 */
	public ArrayList<String> get3DTickets(){
		ArrayList<String> Ticks = new ArrayList<>();

		sortByDay();
		for(Ticket ThreeDTickets : ticketList)
			if(ThreeDTickets.getFormat()==Format.THREE_D){
				Ticks.add(ThreeDTickets.toString());
			}
		return Ticks;
	}
/**
 * Returns an arrayList of strings which represent tickets,
 * 					 in chronological order use the toString of each Ticket in the ticketList
 */
	public ArrayList<String> getAllTickets(){
		ArrayList<String> AllTicks = new ArrayList<String>();
		sortByDay();
		for(Ticket ticks : ticketList)
				{AllTicks.add(ticks.toString());	}	
		return AllTicks;
	}

/**
 * Returns an Arraylist of string representation of MoviePass tickets sorted by movieId
 */
	public ArrayList<String> getMoviePassTickets() {
		ArrayList<String> MPassTicks = new ArrayList<>();
		sortById();
		for(Ticket a : ticketList)
			if(a.getType().equals("MoviePass")){
				MPassTicks.add(a.toString());
			}
		return MPassTicks;
	}

/**
 * Reads from a file and populates an arraylist of Ticket objects
 */
	public void readFile(File file) throws FileNotFoundException {

//			movieN=ticket[0];
//			rating=ticket[1];
//			d=Integer.parseInt(ticket[2]);
//			t=Integer.parseInt(ticket[3]);
//			f=ticket[4];
//			type=ticket[5];
//				id=Integer.parseInt(ticket[6]);
//			addTicket(movieN, rating, d, t, f, type, id);
//		}	
Scanner input = new Scanner(file);
		
		while (input.hasNextLine()) 
		{
			
			String[] ticket = input.nextLine().split(":");
			addTicket(ticket[0], 
					ticket[1], 
					Integer.parseInt(ticket[2]),
					Integer.parseInt(ticket[3]), 
					ticket[4], ticket[5], 
					Integer.parseInt(ticket[6]));
			
		}
		
		input.close();
	}

/**
 * Sorts the arraylist of Ticket object by day
 */
	private void sortByDay(){
		Ticket temp;
		for(int x =1;x < ticketList.size();x++)
		{
			for(int y = x ;y > 0; y--){
				if(ticketList.get(y - 1).getDay()>ticketList.get(y).getDay()){
					temp = ticketList.get(y);
					ticketList.set(y, ticketList.get(y-1));
					ticketList.set(y-1, temp);
				}
			}
		}

	}

/**
 * Sorts the arraylist of Ticket object by id
 */
	private void sortById() 
	{
		Ticket temp;
		for(int i=1;i< ticketList.size();i++)
		{
			for(int j=i;j>0;j--){
				if(ticketList.get(j-1).getId()>ticketList.get(j).getId()){
					temp = ticketList.get(j);
					ticketList.set(j, ticketList.get(j-1));
					ticketList.set(j-1, temp);
				}
			}
		}

	}
	
}
