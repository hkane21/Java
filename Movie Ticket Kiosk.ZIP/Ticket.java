import java.text.Format;
import java.text.NumberFormat;

public abstract class Ticket extends MovieTicketManager{

	protected String type;
	protected String Name;
	TicketType ticktype;
	protected int Day;
	protected Format format;
	protected Rating rating;
	protected double price;
	protected int Time;
	private NumberFormat currencyFormat=NumberFormat.getCurrencyInstance();
	
	/**
	 * No arg constructor
	 */
	public Ticket() {}
	/**
	 * 
	 * @param Name of movie
	 * @param movieRating rating of movie
	 * @param day of movie airing
	 * @param t time of movie
	 * @param f format of movie
	 * @param type of movie
	 */
	public Ticket(String Name, String movieRating, int day, int t, String f, String type){
		this.Name = Name;

		switch (movieRating) {
		case "R":
			this.rating = Rating.R;
			break;
		case "PG":
			this.rating = Rating.PG;
			break;
		case "PG13":
			this.rating = Rating.PG13;
			break;
		case "G":
			this.rating = Rating.G;
			break;
		case "NR":
			this.rating = Rating.NR;
			break;
		}
		Day = day;
		Time = t;
		switch(f){
		case "IMAX": format = Format.IMAX;
				break;
		case "3D": format = Format.THREE_D;
				break;
		case "NONE": format = Format.NONE;
		}
		this.type = type;
	}
	/**
	 * 
	 * @param Name of movie
	 * @param Time of movie
	 * @param Day of movie
	 * @param format of movie
	 * @param rating of movie
	 * @param type of movie ticket
	 */
	public Ticket(String movieName, int movieDay, int movieTime,  
				  String format, String rating, String type) {
		switch (format) {
		case "3D":
			this.format = Format.THREE_D;
			break;
		case "IMAX":
			this.format = Format.IMAX;
			break;
		case "NONE":
			this.format = Format.NONE;
			break;
		}
		switch (rating) {
		case "R":
			this.rating = Rating.R;
			break;
		case "PG":
			this.rating = Rating.PG;
			break;
		case "PG13":
			this.rating = Rating.PG13;
			break;
		case "G":
			this.rating = Rating.G;
			break;
		case "NR":
			this.rating = Rating.NR;
			break;
		}
		this.Name = movieName;
		this.Time = movieTime;
		this.Day = movieDay;
		this.type = type;
	}
	
	public abstract double calculateTicketPrice();
	public abstract int getId();
	
	
	
	/**
	 * @return the type of movie
	 */
	public String getType() {
		return type;
	}
	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	/**
	 * @param movieName the movieName to set
	 */
	public void setMovieName(String movieName) {
		this.Name = movieName;
	}
	/**
	 * 
	 * @return type of ticket
	 */
	public TicketType getTickType() {
		return ticktype;
	}
	/**
	 * @param movieDay the day the movie is airing
	 */
	public void setDay(int movieDay) {
		this.Day = movieDay;
	}
	/**
	 * @param movieTime the time the movie begins
	 */
	public void setMovieTime(int movieTime) {
		this.Time = movieTime;
	}
	/**
	 * @param format the format to set
	 */
	public void setFormat(Format format) {
		this.format = format;
	}
	/**
	 * @param rating the movie rating to set
	 */
	public void setRating(Rating rating) {
		this.rating = rating;
	}
	/**
	 * @return the name of the movie
	 */
	public String getMovieName() {
		return Name;
	}
	/**
	 * @return the day of the movie
	 */
	public int getDay() {
		return Day;
	}
	/**
	 * @return the time the movie starts
	 */
	public int getMovieTime() {
		return Time;
	}
	/**
	 * @return the format
	 */
	public Format getFormat() {
		return format;
	}
	/**
	 * @return the rating of the movie to see if it's age appropriate
	 */
	public Rating getRating() {
		return rating;
	}
	/**
	 * Return to String method of entire movie ticket data
	 */
	@Override
	public String toString() {
		return  "Format: " + format +
				" Movie: " + Name +
				" Rating: " + rating +
				" Day: " + Day +
				" Time: " + Time +
				" Price: " + currencyFormat.format(price);
	}

}

