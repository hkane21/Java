import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
/**
 * 
 * @author Hassan
 *
 */
public class TwoDimRaggedArrayUtility {
	 /**
	  * 
	  * @param data two dimensional array 
	  * @return returns average of arrays
	  */
	
	static double getAverage (double[][]data) {
		int totaldata = 0;
		double average;
		for (int row=0;row < data.length ;row++) {
			for (int col=0; col<data[row].length; col++) {
				totaldata++;
			}
		}
		average = getTotal(data)/totaldata;
		
		return average;
	}
	/**
	 * This static method returns the total sum of the integers in the columns
	 * @param data two dimensional array containing the data
	 * @param col columns to be returned 
	 * @return returns the total sum of the columns
	 */
	
	static double getColumnTotal(double [][]data, int col) {

		double total = 0.0;
		for (int i = 0; i<data.length; i++) {
			if (col<data[i].length) {
				try {
					total += data[i][col];
				}
				catch (Exception e) {
					total += 0;
				}
			}
		}
		return total;
	}
	/**
	 * static method gets the highest number in the array
	 * @param data two dimensional array
	 * @return returns the highest number in data
	 */
	static double getHighestInArray(double [][]data) {
		double highest = data[0][0];
		for (int index = 0; index < data.length; index++) {
			for (int i = 0; i < data[index].length; i++) {
				if (data[index][i] > highest) {
				highest = data[index][i];
			}
				}
		}
		return highest;
	}
	/**
	 * Gets the highest number in the columns
	 * @param data two dimensional array
	 * @param col column number
	 * @return returns the highest number in the columns
	 */
	static double getHighestInColumn(double[][]data, int col) {
		
		double highest = 0.0;
		
		for (int i = 0; i < data.length; i++) {
			if (col>=data[i].length) {
				continue;
			}
			else {
				if (highest < data[i][col]) {
					highest = data[i][col];
					
				}

			} 
		}

		return highest;
	}
	/**
	 * Static int method gets the highest column index
	 * @param data two dimensional array
	 * @param col column number
	 * @return returns the index of the highest number in the column
	 */
	static int getHighestInColumnIndex (double [][]data, int col) {
		double highest = 0.0;
		int index = 0;

		for (int i = 0; i < data.length; i++) {
			if (col>=data[i].length) {
				continue;
			}
			else {
				if (highest < data[i][col]) {
					highest = data[i][col];
					index = i;
				}

			} 
		}

		return index;
	}
	/**
	 * Static double that gets the highest number in a row
	 * @param data a 2d array
	 * @param row the row number
	 * @return returns the highest number in a row
	 */
	static double getHighestInRow (double[][]data, int row) {
		double highest = data[row][0];
			for (int col=0; col < data[row].length; col++) {
				
				if (data[row][col]>highest) {
					highest = data[row][col];
				}
			
		}
		return highest;
	}
	/**
	 * Static int gets the index of the highest number in the row
	 * @param data two dimensional array
	 * @param row the row number
	 * @return returns the index of the highest number in the row
	 */
	
	static int getHighestInRowIndex (double[][]data, int row) {
		double highest=data[row][0];
		int index=0;
		
			for(int i=1; i<data[row].length;i++) {
				if(data[row][i]>highest) {
					index=i;		
				}
		}
		return index; 
	}
	/**
	 * Static double that gets the lowest number in the 2d array
	 * @param data the 2d array
	 * @return returns the lowest number in the entire array
	 */
	static double getLowestInArray(double[][]data) {
		double lowest=data[0][0];
		for (int index = 0; index < data.length; index++) {
			for (int i = 0; i<data[index].length; i++) {
				if (data[index][i]<lowest) {
					lowest = data[index][i];
				}
			}
		}
		return lowest;
	}
	/**
	 * Gets the lowest number in a column
	 * @param data 2d array
	 * @param col column number
	 * @return returns the lowest number in the column
	 */
	static double getLowestInColumn(double[][]data, int col) {
		
		double lowest = 10000000000000000.00;
	    for (int i = 0;i < data.length;i++) {
	      if (col >= data[i].length) {
	        continue;
	      }
	      if (lowest > data[i][col] ) {
	        lowest = data[i][col];
	      }
	    }
	    return lowest;
	  
	}
	/**
	 * gets the index of the lowest number in a column
	 * @param data 2d array
	 * @param col column number
	 * @return returns the index of the lowest number in a column
	 */
	static int getLowestInColumnIndex(double[][]data,int col) {

		double lowest = 1000000000000000000.00;
	    int index = -1;
	    for (int i = 0;i < data.length;i++) {
	      if (col >= data[i].length) {
	        continue;
	      }
	      if (lowest>data[i][col] ) {
	        lowest = data[i][col];
	        index = i;
	      }
	    }
	    return index;
	}
	/**
	 * Gets lowest number in a row
	 * @param data 2d array
	 * @param row row number
	 * @return returns the llowest number in a row
	 */
	static double getLowestInRow(double[][]data, int row) {
		double lowest=data[row][0];
			for(int i =1; i<data[row].length;i++) {
				if(lowest>data[row][i]) {
					lowest=data[row][i];		
				}
			}
			return lowest;
	}
	/**
	 * Gets index of lowest number in row
	 * @param data 2d array 
	 * @param row row number
	 * @return returns index of lowest number in row
	 */
	static int getLowestInRowIndex(double[][]data, int row) {
		double lowest=data[row][0];
		int index=0;
			for(int i=0; i<data[row].length;i++) {
				if(data[row][i]<lowest) {
					lowest=data[row][i];
					index=i;		
				}
		}
		return index;
	}
	/**
	 * Gets the total sum of number in a row
	 * @param data 2d array
	 * @param row row number
	 * @return returns total of numbers in row
	 */
	static double getRowTotal (double[][]data, int row) {
		double total = 0.0;
			for(int col=0;col<data[row].length;col++) {
				total += data[row][col];
			}
		return total;
	}
	/**
	 * Gets total sum of numbers in array
	 * @param data 2d array
	 * @return returns the total sum of numbers in entire 2d array
	 */
	static double getTotal (double[][]data) {
		double total=0;
		for (int row=0;row < data.length ;row++) {
			
			for (int col=0; col<data[row].length; col++) {
				total += data[row][col];
			}
		}
		return total;
	}
	/**
	 * Reads the file of the data loaded
	 * @param file the file of data that is to be loaded
	 * @return returns the array in file
	 * @throws FileNotFoundException
	 */
	@SuppressWarnings("resource")
	static double[][]readFile(File file)throws FileNotFoundException {

		double[] Saved;
		String[] SPACE;
		String str;
		int row = 0;
		double[][] rarray  = new double[1000][1000];
		Scanner input = new Scanner(file);
				try {
					input = new Scanner(file);
				}catch (FileNotFoundException e) {
		            System.out.println("File not found");
		            return null;
		        }
					while(input.hasNext()) {
						str = input.nextLine();
						SPACE = str.split(" ");
						Saved = new double[SPACE.length];
						for(int i = 0; i < SPACE.length; i++)
							Saved[i] = Double.parseDouble(SPACE[i]);
						rarray[row] = Saved;
						row++;
						
					}
					input.close();
			
				return rarray;
    }
		
	/**
	 * Writes the data to file and outputs it
	 * @param data 2d array data
	 * @param outPutFile file is outputted in notepad
	 * @throws java.io.FileNotFoundException
	 */
	
	static void writeToFile (double[][]data, File outPutFile) throws java.io.FileNotFoundException{
		PrintWriter write;
		try {
		write=new PrintWriter (outPutFile);
		for(int i=0;i<data.length;i++) {
			for(int ii=0;ii<data[i].length;ii++) {
				write.print(data[i][ii]+" ");
			}
			write.println(" ");
		}
		write.close();
		}
		catch(FileNotFoundException e) {
			System.out.println("Cannot find your file, Try Again !!!");
			System.exit(0);
		}
		
	} 
		/**
		 * Gets the lowest positive number in a column
		 * @param data 2d array
		 * @param col column number
		 * @return the lowest positive number in a column
		 */
	public static double getLowestPositiveCol(double[][] data, int col){
		double lowest = data[0][0];

		
		    for (int x = 0; x < data.length; x++)
		    {
		        for (int y = 0; y < data[x].length; y++)
		        {
		            if (lowest > data[x][y])
		            {
		                lowest = data[x][y];
		            }
		        } 
		    }  

		    return lowest;
		 }
		/**
		 * Gets index of lowest positive number in a column
		 * @param data 2d array
		 * @param col column number
		 * @return returns the index of lowest positive number in a column
		 */
	
	public static int getLowestPositiveColIndex(double[][] data, int col){
		
		double lowest = data[0][0];
		int init = 0;
		int index =-1;		
		for(int i = 0; i < data.length; i++) {
			if(data[i].length+(index) >= col && data[i][col] > 0) {
				lowest = data[i][col];
				index = i;
				init = i;
				break;
			}
		}
		for(int i = init; i < data.length; i++) {
			if(data[i].length-1 >= col) 
				if(data[i][col] < lowest && data[i][col] > 0) {
					lowest = data[i][col];
					index = i;
				}
		}

		    return index;
		 }

		
}
