

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TwoDimRaggedArrayUtilitySTUDENT_Test {
	//STUDENT fill in dataSetSTUDENT with values, it must be a ragged array
	private double[][] dataSetSTUDENT = {
			{12536.54, 45665.05, 21543.66, 75324.57, 33884.48, 65982.39},
			{28762.21, 35762.42, 19546.63},
			{48962.34, 28552.95, 23863.66, 54992.97},
			{22567.63, 36237.64, 42862.95, 54384.86, 37944.37},
			{31843.86, 36546.57, 34557.68, 63872.39, 42657.70, 45924.51},
			{26574.65, 32653.46, 22563.87, 89352.68, 52873.49}};
	
	private File inputFile,outputFile;

	@Before
	public void setUp() throws Exception {
		outputFile = new File("TestOut.txt");
	}

	@After
	public void tearDown() throws Exception {
		dataSetSTUDENT = null;
		inputFile = outputFile = null;
	}

	/**
	 * Student Test getTotal method
	 * Return the total of all the elements in the two dimensional array
	 */
	@Test
	public void testGetTotal() {
		//fail("Student testGetTotal not implemented");	
		assertEquals(1168798.18,TwoDimRaggedArrayUtility.getTotal(dataSetSTUDENT),.001);
	}

	/**
	 * Student Test getAverage method
	 * Return the average of all the elements in the two dimensional array
	 */
	@Test
	public void testGetAverage() {
		//fail("Student testGetAverage not implemented");	
		assertEquals(40303.38552,TwoDimRaggedArrayUtility.getAverage(dataSetSTUDENT),.001);
	}

	/**
	 * Student Test getRowTotal method
	 * Return the total of all the elements of the row.
	 * Row 0 refers to the first row in the two dimensional array
	 */
	@Test
	public void testGetRowTotal() {
		//fail("Student testGetRowTotal not implemented");	
		assertEquals(84071.26,TwoDimRaggedArrayUtility.getRowTotal(dataSetSTUDENT,1),.001);
	}


	/**
	 * Student Test getColumnTotal method
	 * Return the total of all the elements in the column. If a row in the two dimensional array
	 * doesn't have this column index, it is not an error, it doesn't participate in this method.
	 * Column 0 refers to the first column in the two dimensional array
	 */
	@Test
	public void testGetColumnTotal() {
	//	fail("Student testGetColumnTotal not implemented");	
		assertEquals(111906.9,TwoDimRaggedArrayUtility.getColumnTotal(dataSetSTUDENT,5),.001);
	}


	/**
	 * Student Test getHighestInArray method
	 * Return the largest of all the elements in the two dimensional array.
	 */
	@Test
	public void testGetHighestInArray() {
		//fail("Student testGetHighestInArray not implemented");	
		assertEquals(89352.68,TwoDimRaggedArrayUtility.getHighestInArray(dataSetSTUDENT),.001);
	}
	

	/**
	 * Test the writeToFile method
	 * write the array to the outputFile File
	 * then read it back to make sure formatted correctly to read
	 * @throws FileNotFoundException 
	 * 
	 */
	@Test
	public void testWriteToFile() throws FileNotFoundException {
		//fail("Student testWriteToFile not implemented");
		double[][] array=null;
		try {
			TwoDimRaggedArrayUtility.writeToFile(dataSetSTUDENT, outputFile);
		} catch (Exception e) {
			fail("This should not have caused an Exception");
		}
		array = TwoDimRaggedArrayUtility.readFile(outputFile);
		assertEquals(12536.54, array[0][0],.001);
		assertEquals(45665.05, array[0][1],.001);
		assertEquals(21543.66, array[0][2],.001);
		assertEquals(75324.57, array[0][3],.001);
		assertEquals(33884.48, array[0][4],.001);
		assertEquals(65982.39, array[0][5],.001);
		assertEquals(28762.21, array[1][0],.001);
		assertEquals(35762.42, array[1][1],.001);
		assertEquals(19546.63, array[1][2],.001);
		assertEquals(48962.34, array[2][0],.001);
		assertEquals(28552.95, array[2][1],.001);
		assertEquals(23863.66, array[2][2],.001);
		assertEquals(54992.97, array[2][3],.001);
		assertEquals(22567.63, array[3][0],.001);
		assertEquals(36237.64, array[3][1],.001);
		assertEquals(42862.95, array[3][2],.001);
		assertEquals(54384.86, array[3][3],.001);
		assertEquals(37944.37, array[3][4],.001);
		assertEquals(31843.86, array[4][0],.001);
		assertEquals(36546.57, array[4][1],.001);
		assertEquals(34557.68, array[4][2],.001);
		assertEquals(63872.39, array[4][3],.001);
		assertEquals(42657.70, array[4][4],.001);
		assertEquals(45924.51, array[4][5],.001);
		assertEquals(26574.65, array[5][0],.001);
		assertEquals(32653.46, array[5][1],.001);
		assertEquals(22563.87, array[5][2],.001);
		assertEquals(89352.68, array[5][3],.001);
		assertEquals(52873.49, array[5][4],.001);
		
	
	}

}