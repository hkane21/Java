/**
 * This class calculates the holiday bonus in relation to the values in the array
 * @author Hassan
 *
 */
public class HolidayBonus {
/**
 * 
 * @param data the 2d arrays data goes in this variable
 * @param high the highest bonus goes to highest amount	
 * @param low the lowest bonus goes to lowest amount		
 * @param other any value between the highest and lowest is considered other
 * @return returns the bonus 
 */
	static double[]calculateHolidayBonus(double[][]data, double high, double low, double other){
		
		int numStores = data.length;
		int numCategories = 0;
		double[] bonus = new double[numStores];
		//find holiday bonus for each row
		for(int store = 0; store<numStores; store++){
			bonus[store] = 0;
			numCategories = data[store].length;
			System.out.println("row "+store+" columns "+numCategories);
			for (int category=0;category<numCategories;category++){
				//look at the highest for each column and see if it matches the row
			   if(TwoDimRaggedArrayUtility.getHighestInColumnIndex(data, category)==store){
					if(data[store][category]>0)
						bonus[store] += high;
				}
				//GET THE LOWEST POSITIVE INTEGER IN EACH ROW
				else if(TwoDimRaggedArrayUtility.getLowestPositiveColIndex(data, category)==store){
					if(data[store][category]>0)
						bonus[store]+= low;
				}
				//if not lowest or highest, received "other" bonus
				else
					if(data[store][category]>0)
						bonus[store] += other;
			}
		}
		return bonus;
	}
	
	/**
	 * calculates the total holiday bonuses
	 * @param data the 2d arrays data goes in this variable
	 * @param high the highest bonus goes to highest amount
	 * @param low the lowest bonus goes to lowest amount
	 * @param other other any value between the highest and lowest is considered other
	 * @return returns the total of the holiday bonuses
	 */

	static double calculateTotalHolidayBonus(double[][]data, double high, double low, double other) {
		double total=0;
		double[] bonuses = HolidayBonus.calculateHolidayBonus(data, high, low, other);
		for(int i=0;i<bonuses.length;i++)
			{total += bonuses[i];}
		return total;
	}
}
	